package iuh.edu.fit.core.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
public class Album {
    private String albumId;
    private String title;
    private double price;
    private int yearOfRelease;
    private String downloadLink;

}
