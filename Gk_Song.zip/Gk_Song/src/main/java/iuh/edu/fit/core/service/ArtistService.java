package iuh.edu.fit.core.service;

import iuh.edu.fit.core.dto.ArtistDTO;
import iuh.edu.fit.core.entity.Artist;

public interface ArtistService {
    boolean addArtist (ArtistDTO artistDTO);
}
