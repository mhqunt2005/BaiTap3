package iuh.edu.fit.core.service.Impl;

import iuh.edu.fit.core.dto.ArtistDTO;
import iuh.edu.fit.core.entity.Artist;
import iuh.edu.fit.core.repository.ArtistRepository;
import iuh.edu.fit.core.service.ArtistService;
import iuh.edu.fit.insfrastructure.mapper.GenericDataMapper;

public class ArtistServiceImpl implements ArtistService {
    private ArtistRepository artistRepository;
    private GenericDataMapper mapper;

    public ArtistServiceImpl(ArtistRepository artistRepository, GenericDataMapper mapper) {
        this.artistRepository = artistRepository;
        this.mapper = mapper;
    }

    @Override
    public boolean addArtist(ArtistDTO artistDTO) {
        if(artistDTO == null){
            throw new IllegalArgumentException("artist khong dc null");
        }

        if(artistDTO.getArtistId() == null){
            throw new IllegalArgumentException("ma artist khong dc null");
        }

        if(artistDTO.getName() == null || artistDTO.getName().isBlank()){
            throw new IllegalArgumentException("ten artist khong dc null hoac rong");
        }

        if(artistDTO.getUrl() == null || artistDTO.getUrl().isBlank()){
            throw new IllegalArgumentException("url cua artist khong duoc null hoac rong");
        }

        if(artistDTO.getBirthDate() == null){
            throw new IllegalArgumentException("ngay sinh cua artist khong duoc null");
        }
        Artist artist = mapper.ToObject(mapper.toMap(artistDTO), Artist.class);
        return artistRepository.addArtist(artist);
    }
}
