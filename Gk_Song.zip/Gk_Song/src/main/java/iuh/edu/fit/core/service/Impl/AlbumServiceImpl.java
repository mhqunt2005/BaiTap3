package iuh.edu.fit.core.service.Impl;

import iuh.edu.fit.core.dto.AlbumDTO;
import iuh.edu.fit.core.entity.Album;
import iuh.edu.fit.core.repository.AlbumRepository;
import iuh.edu.fit.core.service.AlbumService;
import iuh.edu.fit.insfrastructure.mapper.GenericDataMapper;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class AlbumServiceImpl implements AlbumService {
    private AlbumRepository albumRepository;
    private GenericDataMapper mapper;

    public AlbumServiceImpl(AlbumRepository albumRepository, GenericDataMapper mapper) {
        this.albumRepository = albumRepository;
        this.mapper = mapper;
    }

    @Override
    public boolean updatePriceOfAlbum(String idAlbum, double newPrice) {
         if(idAlbum == null || idAlbum.isBlank()){
            throw new IllegalArgumentException("Mã Album không được null hoặc rỗng");
         }

         if (newPrice < 0){
             throw new IllegalArgumentException("Giá mới không được bé hơn không");
         }
        return albumRepository.updatePriceOfAlbum(idAlbum, newPrice);
    }

    @Override
    public List<AlbumDTO> listAlbumByGenre(String genreName) {
        if(genreName == null || genreName.isBlank()){
            throw new IllegalArgumentException("Tên thể loại không được null hoặc rỗng");
        }
        List<Album> albums = albumRepository.listAlbumByGenre(genreName);
        return albums.stream().map(a->mapper.ToObject(mapper.toMap(a),AlbumDTO.class)).collect(Collectors.toUnmodifiableList());
    }

    @Override
    public Map<String, Long> getNumberOfAlbumsByGenre() {
        return albumRepository.getNumberOfAlbumsByGenre();
    }
}
