package iuh.edu.fit.core.repository;

import iuh.edu.fit.core.entity.Album;

import java.util.List;
import java.util.Map;

public interface AlbumRepository {
    boolean updatePriceOfAlbum(String id, double newPrice);
    List<Album> listAlbumByGenre (String genreName);
    Map<String, Long> getNumberOfAlbumsByGenre();
}
