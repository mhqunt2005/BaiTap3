package iuh.edu.fit.core.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import iuh.edu.fit.core.entity.Album;
import lombok.*;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
@ToString
@JsonIgnoreProperties(ignoreUnknown = true)
public class SongDTO {
    @JsonProperty("songId")
    private String songId;
    private String name;
    private String runtime;
    private String lyric;
    private String fileLink;
    private Album albumId;

}
