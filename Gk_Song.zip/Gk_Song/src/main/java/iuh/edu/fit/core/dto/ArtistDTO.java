package iuh.edu.fit.core.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

import java.time.LocalDate;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
@ToString
@JsonIgnoreProperties(ignoreUnknown = true)
public class ArtistDTO {
    @JsonProperty("artistId")
    private String artistId;
    private String name;
    private LocalDate birthDate;
    private String url;
}
