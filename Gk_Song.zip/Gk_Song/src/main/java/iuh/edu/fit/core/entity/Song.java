package iuh.edu.fit.core.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
public class Song {
    private String songId;
    private String name;
    private String runtime;
    private String lyric;
    private String fileLink;
    private Album albumId;

}
