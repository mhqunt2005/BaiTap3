package iuh.edu.fit.core.service;

import iuh.edu.fit.core.dto.AlbumDTO;
import iuh.edu.fit.core.entity.Album;

import java.util.List;
import java.util.Map;

public interface AlbumService {
    boolean updatePriceOfAlbum(String id, double newPrice);
    List<AlbumDTO> listAlbumByGenre (String genreName);
    Map<String, Long> getNumberOfAlbumsByGenre();
}
