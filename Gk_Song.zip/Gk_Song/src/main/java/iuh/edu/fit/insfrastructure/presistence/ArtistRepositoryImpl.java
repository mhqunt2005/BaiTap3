package iuh.edu.fit.insfrastructure.presistence;

import iuh.edu.fit.core.entity.Artist;
import iuh.edu.fit.core.repository.ArtistRepository;
import iuh.edu.fit.insfrastructure.db.Neo4jConnManager;
import iuh.edu.fit.insfrastructure.mapper.GenericDataMapper;
import org.neo4j.driver.Result;
import org.neo4j.driver.Session;

import java.util.Map;

public class ArtistRepositoryImpl implements ArtistRepository {
    private Neo4jConnManager neo4jConnManager;
    private GenericDataMapper mapper;

    public ArtistRepositoryImpl(Neo4jConnManager neo4jConnManager, GenericDataMapper mapper) {
        this.neo4jConnManager = neo4jConnManager;
        this.mapper = mapper;
    }

    @Override
    public boolean addArtist(Artist artist) {
        String query = "MERGE (a:Artist{artistId:$artistId})" + "set a.name = $name, a.birthDate=$birthDate, a.url=$url RETURN a";
        try(Session session = neo4jConnManager.openSession()){
            return session.executeWrite(tx -> {
                Result result = tx.run(query, Map.of("artistId",artist.getArtistId(), "name", artist.getName(),
                                                    "birthDate", artist.getBirthDate(), "url",artist.getUrl()));
                return result.hasNext();
            });
        }
    }
}
