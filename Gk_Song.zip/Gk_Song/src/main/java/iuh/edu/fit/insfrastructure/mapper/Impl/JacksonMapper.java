package iuh.edu.fit.insfrastructure.mapper.Impl;

import iuh.edu.fit.insfrastructure.mapper.GenericDataMapper;
import tools.jackson.databind.ObjectMapper;

import java.util.Map;

public class JacksonMapper implements GenericDataMapper {
    private ObjectMapper objectMapper;

    public JacksonMapper(){objectMapper = new ObjectMapper();}


    @Override
    public Map<String, Object> toMap(Object object) {
        if(object == null ){
            return null;
        }
        return objectMapper.convertValue(object, Map.class);
    }

    @Override
    public <T> T ToObject(Map<String, Object> data, Class<T> clazz) {
        if (data ==null){
            return null;
        }
        return objectMapper.convertValue(data, clazz);
    }
}
