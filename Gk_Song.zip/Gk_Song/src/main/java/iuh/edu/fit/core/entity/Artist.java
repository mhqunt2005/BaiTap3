package iuh.edu.fit.core.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
public class Artist {
    private String artistId;
    private String name;
    private LocalDate birthDate;
    private String url;
}
