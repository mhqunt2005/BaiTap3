package iuh.edu.fit.core.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
@ToString
@JsonIgnoreProperties(ignoreUnknown = true)
public class AlbumDTO {
    @JsonProperty("albumId")
    private String albumId;
    private String title;
    private double price;
    private int yearOfRelease;
    private String downloadLink;

}
