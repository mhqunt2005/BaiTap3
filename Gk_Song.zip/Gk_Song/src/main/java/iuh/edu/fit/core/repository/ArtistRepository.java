package iuh.edu.fit.core.repository;

import iuh.edu.fit.core.entity.Artist;

public interface ArtistRepository {
    boolean addArtist (Artist artist);
}
