package iuh.edu.fit.insfrastructure.presistence;

import iuh.edu.fit.core.entity.Album;
import iuh.edu.fit.core.repository.AlbumRepository;
import iuh.edu.fit.insfrastructure.db.Neo4jConnManager;
import iuh.edu.fit.insfrastructure.mapper.GenericDataMapper;
import org.neo4j.driver.Result;
import org.neo4j.driver.Session;

import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

public class AlbumRepositoryImpl implements AlbumRepository {
    private Neo4jConnManager neo4jConnManager;
    private GenericDataMapper mapper;

    public AlbumRepositoryImpl(Neo4jConnManager neo4jConnManager, GenericDataMapper mapper) {
        this.neo4jConnManager = neo4jConnManager;
        this.mapper = mapper;
    }

    @Override
    //update Gia khi biet id
    public boolean updatePriceOfAlbum(String id, double newPrice) {
        String query = "MERGE (al:Album {albumId:$id}) set al.price=$newPrice return al";
        try(Session session = neo4jConnManager.openSession()){
            return session.executeWrite(tx -> {
                Result result = tx.run(query, Map.of("id",id,"newPrice",newPrice));
                return result.hasNext();
            });
        }
    }

    @Override
    //tim kiem khi biet ten the loai
    public List<Album> listAlbumByGenre(String genreName) {
        String query = "MATCH (al:Album)-[:BELONG_TO]->(g:Genre) WHERE g.name=$genreName RETURN al";
        Map<String, Object> pramas = Map.of("genreName", genreName);
        try(Session session = neo4jConnManager.openSession()){
            return session.executeWrite(tx -> {
                return tx.run(query, pramas).list(record ->
                        mapper.ToObject(record.get("al").asNode().asMap(), Album.class));
            });
        }
    }

    @Override
    // thong ke album theo the loai ca sap xep theo kq tang dan
    public Map<String, Long> getNumberOfAlbumsByGenre() {
        String query="MATCH (al:Album)-[:BELONG_TO]->(g:Genre) RETURN g.name as genre, count(al) as Total ORDER BY Total ASC"; // tang dan
        // ORDER BY Total DESC de giam dan
        try(Session session = neo4jConnManager.openSession()){
            return session.executeRead(tx -> {
                return tx.run(query).list().stream().collect(Collectors
                        .toMap(record -> record.get("genre").asString(),
                                        record -> record.get("Total").asLong()));
            });
        }
    }

    //public double calculateTotalOrder(String orderId){
    //        String query="MATCH (o:Order {order_id:$order_id})-[r:ORDERS]->(p:Product)\n" +
    //                "RETURN sum(r.quantity * r.unit_price * (1 - r.discount)) AS total";
    //        try(Session session= connManager.openSession()) {
    //            return session.executeRead(tx->{
    //               var record=tx.run(query, Map.of("order_id",orderId)).single();
    //
    //               if(record.get("total").isNull()){
    //                   return 0.0;
    //               }
    //
    //               return record.get("total").asDouble();
    //            });
    //        }
    //    }


    // Add
    //@Override
    //    public boolean addOrUpdateProduct(Product product) {
    //        String query ="MERGE(p:Product{productId:$productId}) set p.productName=$productName, p.unit=$unit,\n" +
    //                "p.unitPrice=$unitPrice,p.unitsInStock=$unitsInStock RETURN p";
    //        try(Session session= neo4jConnManager.opSession()) {
    //            return session.executeWrite(tx->{
    //                Result result=tx.run(query,Map.of("productId",product.getProductId(),
    //                        "productName",product.getProductName(),"unit",product.getUnit(),"unitPrice",product.getUnitPrice(),
    //                        "unitsInStock",product.getUnitsInStock()));
    //                return result.hasNext();
    //            });
    //        }
    //    }

}
