package iuh.edu.fit.insfrastructure.db;

import org.neo4j.driver.*;


public class Neo4jConnManager implements AutoCloseable{
    private final Driver driver;
    private final String dbName;

    public Neo4jConnManager(String uri,String user,String pass, String dbName) {
        this.driver = (Driver) GraphDatabase.driver(uri, AuthTokens.basic(user,pass));
        this.dbName = dbName;
    }

    public Session openSession(){
        return driver.session(SessionConfig.forDatabase(dbName));
    }


    @Override
    public void close() throws Exception {

    }
}
