
package iuh.edu.fit.presentation;

import iuh.edu.fit.core.entity.Genre;
import iuh.edu.fit.core.repository.AlbumRepository;
import iuh.edu.fit.core.repository.ArtistRepository;
import iuh.edu.fit.core.service.AlbumService;
import iuh.edu.fit.core.service.Impl.AlbumServiceImpl;
import iuh.edu.fit.core.service.Impl.ArtistServiceImpl;
import iuh.edu.fit.insfrastructure.db.Neo4jConnManager;
import iuh.edu.fit.insfrastructure.mapper.GenericDataMapper;
import iuh.edu.fit.insfrastructure.mapper.Impl.JacksonMapper;
import iuh.edu.fit.insfrastructure.presistence.AlbumRepositoryImpl;
import iuh.edu.fit.insfrastructure.presistence.ArtistRepositoryImpl;

import java.util.Map;

public class Test {
    public static void main(String[] args) {
        String url = "neo4j://127.0.0.1:7687";
        String user = "neo4j";
        String password = "sapassword";
        String dbName = "neo4j";

        Neo4jConnManager connManager = new Neo4jConnManager(url, user, password, dbName);
        GenericDataMapper dataMapper = new JacksonMapper();

        ArtistRepositoryImpl artistRepository=new ArtistRepositoryImpl(connManager,dataMapper);
        ArtistServiceImpl artistService = new ArtistServiceImpl(artistRepository, dataMapper);

        AlbumRepositoryImpl albumRepository = new AlbumRepositoryImpl(connManager, dataMapper);
        AlbumServiceImpl albumService = new AlbumServiceImpl(albumRepository, dataMapper);



        Map<String, Long> stringLongMap = albumRepository.getNumberOfAlbumsByGenre();
        stringLongMap.forEach((k,v) -> System.out.printf("Genre: %s - Total Album: %d%n", k, v));
    }
}
