package iuh.edu.fit.insfrastructure.mapper;

import java.util.Map;

public interface GenericDataMapper {
    Map<String, Object> toMap(Object object);
    <T> T ToObject(Map<String, Object> data, Class<T> clazz);
}
